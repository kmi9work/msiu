require 'db_core/models/model'
require 'db_core/models/fly_personal'
class Crew < Model
  def Crew.create_table(connection)
    begin
      connection.do("
CREATE TABLE crews(
  id serial PRIMARY KEY,
  pilot_id integer REFERENCES fly_personals(id) NOT NULL,
  stuard1_id integer REFERENCES fly_personals(id) NOT NULL,
  stuard2_id integer REFERENCES fly_personals(id) NOT NULL,
  mechanic_id integer REFERENCES fly_personals(id) NOT NULL,
  second_pilot_id integer REFERENCES fly_personals(id) NOT NULL,
  is_busy boolean DEFAULT false,
  flight_id integer
) WITH OIDS
        ")
      return true
    rescue DBI::ProgrammingError => e
      return false
    end
  end

  def initialize(attributes = {})
    @attributes = {
      :id => nil,
      :pilot_id => nil, 
      :stuard1_id => nil,
      :stuard2_id => nil,
      :mechanic_id => nil,
      :second_pilot_id => nil,
      :is_busy => nil,
      :flight_id => nil
    }
    attributes.each do |k, v|
      @attributes[k.to_sym] = v unless v.nil? or v == ''
    end
  end
  def Crew.find_by_flight_id(connection, flight_id)
    id = id.to_i
    query = ["SELECT * FROM #{table_name()} WHERE flight_id = ?", id]
    r = connection.select_one(*query)
    return nil if r.nil?
    f = self.new
    r.column_names.each do |c|
      f[c.to_sym] = r[c]
    end
    f.pilot = FlyPersonal.find_first(connection,f[:pilot_id]) unless f[:pilot_id].nil?
    f.second_pilot = FlyPersonal.find_first(connection,f[:second_pilot_id]) unless f[:second_pilot_id].nil?
    f.stuard1 = FlyPersonal.find_first(connection,f[:stuard1_id]) unless f[:stuard1_id].nil?
    f.stuard2 = FlyPersonal.find_first(connection,f[:stuard2_id]) unless f[:stuard2_id].nil?
    f.mechanic = FlyPersonal.find_first(connection,f[:mechanic_id]) unless f[:mechanic_id].nil?
    return f
  end
  
end

