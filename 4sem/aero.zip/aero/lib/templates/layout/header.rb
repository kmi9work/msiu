"<!DOCTYPE HTML PUBLIC '-//W3C//DTD HTML 4.01 Transitional//EN'>
<html>
  <head>
    <title>Аэропорт</title>
    <meta http-equiv='Content-Type' content='text/html; charset=UTF-8'>
    <link rel = 'stylesheet' href = '/has9/stylesheets/aero.css' type = 'text/css'>
  </head>
  <body>
    <table class = 'layout'>
        <thead>
            <tr>
                <th>#{@login_link_html}</th>
                <th>Аэропорт</th>
            </tr>
         </thead>
         <tbody>
             <tr>
                <th>#{@menu}</th>
                <td>
"
