"
<table class = 'list'>
  <caption>
    #{@header}<br>
    <span style = 'color: Red;'>#{@message}</span>
  </caption>
  <thead>
  <tbody>
    <tr>
      <th>Информация:</th>
      <td>#{@item[:info]}</td>
    </tr>
  </tbody>
</table>
"

