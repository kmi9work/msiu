"<span style = 'color: Red;'>#{@message}</span>
<input type = 'button' value = 'Назад'
               onclick = 'javascript:document.location=\"aero.rb?controller=Flight&action=edit&id=#{@item[:flight_id]}\"'>"
