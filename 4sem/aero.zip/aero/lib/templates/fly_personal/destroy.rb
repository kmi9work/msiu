"
<h2><span style = 'color: Red;'>#{@message}</span></h2>
<p><a href = 'aero.rb?controller=FlyPersonal&action=list'>Назад</a></p>
"
