"
<h2>Ошибка: <span style = 'color: red;'>#{@message}</font></h2>
<p><a href = 'aero.rb?#{@link}'>Назад</a></p>
"
