class Property < ActiveRecord::Base
  belongs_to :item
end
