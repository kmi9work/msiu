require 'test_helper'

class CatalogueTest < ActiveSupport::TestCase
  # Replace this with your real tests.
  test "create" do
    assert true
=begin
    puts '==========================================='
    a =  Catalogue.new({
      :name => "Catalogue1",
      :info => 'cinfo1'
    })
    assert a.save, true
    
    a =  Catalogue.new({
      :name => "Catalogue2",
      :info => 'cinfo2'
    })
    assert a.save, true
=end
  end
  
end
