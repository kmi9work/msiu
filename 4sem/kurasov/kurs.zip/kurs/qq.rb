while gets
  puts $_.inpect
end
